<?php
namespace App\Services;

use App\Config\DB;
use App\Config\Env;
use PDO;
use Exception;

require_once __DIR__ . '/../config/env.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/ReceiptVerifier.php';

class PaymentService {
    private PDO $pdo;
    private ReceiptVerifier $verifier;

    public function __construct() {
        $this->pdo = DB::pdo();
        $this->verifier = new ReceiptVerifier();
    }

    public function health(): array {
        return ['success'=>true,'message'=>'ok', 'version'=> Env::get('APP_VERSION','1.0.0')];
    }

    public function verifyReceiptUrl(string $url): array {
        $res = $this->verifier->verifyByUrl($url);
        return $res;
    }

    // Example: deposit by receipt URL (verifies then records)
    public function depositByReceiptUrl(int $userId, string $url): array {
        $verify = $this->verifier->verifyByUrl($url);
        if (!$verify['ok']) {
            return ['success'=>false,'message'=>'Verification failed', 'details'=>$verify];
        }
        $p = $verify['parsed'] ?? [];
        if (empty($p['amount'])) {
            return ['success'=>false,'message'=>'Amount not found in receipt','details'=>$verify];
        }
        $amount = (float)$p['amount'];
        $txnId = $p['transaction_id'] ?? null;
        if (!$txnId) {
            return ['success'=>false,'message'=>'Transaction ID not found'];
        }

        // idempotency: refuse duplicate txn_id
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM payments WHERE external_txn_id = ?");
        $stmt->execute([$txnId]);
        if ($stmt->fetchColumn() > 0) {
            return ['success'=>false,'message'=>'Duplicate transaction'];
        }

        $this->pdo->beginTransaction();
        try {
            // 1) record payment
            $stmt = $this->pdo->prepare("INSERT INTO payments (user_id, amount, currency, method, external_txn_id, meta_json, status)
                VALUES (?, ?, ?, ?, ?, ?, 'completed')");
            $currency = $p['currency'] ?? 'ETB';
            $method = $p['source'] ?? 'unknown';
            $meta = json_encode(['receipt_url'=>$url,'parsed'=>$p], JSON_UNESCAPED_UNICODE);
            $stmt->execute([$userId, $amount, $currency, $method, $txnId, $meta]);

            // 2) credit wallet/balance (assumes users table with balance column)
            $this->pdo->exec("UPDATE users SET balance = COALESCE(balance,0) + {$amount} WHERE id = {$userId}");

            $this->pdo->commit();
            return ['success'=>true,'message'=>'Deposit recorded','transaction_id'=>$txnId,'amount'=>$amount,'currency'=>$currency];
        } catch (Exception $e) {
            $this->pdo->rollBack();
            return ['success'=>false,'message'=>'DB error','error'=>$e->getMessage()];
        }
    }

    public function createWithdrawalRequest(int $userId, float $amount, string $methodName, string $account, string $name): array {
        if ($amount <= 0) return ['success'=>false,'message'=>'Invalid amount'];
        $stmt = $this->pdo->prepare("INSERT INTO withdrawals (user_id, amount, method, account, name, status) VALUES (?,?,?,?,?,'pending')");
        $stmt->execute([$userId, $amount, $methodName, $account, $name]);
        return ['success'=>true,'message'=>'Withdrawal requested'];
    }
}
