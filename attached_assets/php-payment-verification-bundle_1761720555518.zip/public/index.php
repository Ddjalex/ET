<?php
// Front controller for the mini API. In cPanel, point your domain or subdomain to /public.
// Then the routes below will be available: /api/payments/*
require_once __DIR__ . '/../routes/payments.php';
